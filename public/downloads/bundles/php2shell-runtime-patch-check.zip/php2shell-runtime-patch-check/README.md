# PHP2Shell 대응: 수정 버전과 웹 서버의 PHP 실행 환경 점검

본문: https://ryuyunseong.github.io/security-blog/posts/php2shell-runtime-patch-check/

## 준비

Python 3.9 이상과 표준 라이브러리. Linux·WSL에서는 python3, Windows PowerShell에서는 python 명령을 사용한다. PHP나 외부 서버는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd php2shell-runtime-patch-check
```

## 포함 파일

- `php2shell_inventory.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 php2shell_inventory.py
echo $?
```

예상 종료 코드: 0. 가상 목록 6건의 분류를 출력하고 비교를 통과한다. 업데이트 대상·워커 반영 검토·업체 공지 대조·웹 실행 환경 미수집·구형 계열·정식 버전 형식 검토가 각각 나타난다.

## 실행 조건과 정리

- ZIP 안의 코드에 가상 입력이 들어 있다. 파일·설정·서버·계정을 추가로 준비하거나 변경하지 않는다.
- 실제 패키지나 웹 실행 환경을 수집하지 않는 분류 예제다. 버전 조건 충족은 웹 워커의 패치 적용을 증명하지 않는다.
- Windows에서는 같은 폴더에서 python -I -B -X utf8 php2shell_inventory.py를 실행하고 $LASTEXITCODE를 조회한다.
- 실행 과정은 파일을 생성하지 않으므로 별도 정리 명령이 필요하지 않다.
