# U-25: world writable 파일 점검

본문: https://ryuyunseong.github.io/security-blog/posts/u-25-world-writable-files/

## 준비

Linux 또는 WSL Ubuntu, Python 3.9 이상과 GNU find. /tmp의 POSIX 파일 모드·심볼릭 링크를 사용한다. Ubuntu 24.04의 Python 3.12.3에서 검증했고 관리자 권한·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-25-world-writable-files
```

## 포함 파일

- `u25_world_writable.py`
- `u25_fixture_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u25_fixture_lab.py ./u25_world_writable.py
echo $?
```

예상 종료 코드: 0. 일반 파일 후보 open-note.txt·other-only.txt 2건이 GNU find와 일치하고 임시 폴더 정리를 출력한다. 수집기와 준비기의 정상 종료는 0, 준비·수집·대조 오류는 2다.

## 실행 조건과 정리

- 빈 폴더에 압축을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 두 Python 파일을 같은 폴더에 둔다.
- Linux/WSL에서는 위 python3 명령을 사용한다. Windows PowerShell에서 전산 예제를 실행할 때는 python3 대신 python을 사용할 수 있다. Bash는 echo $?, PowerShell은 $LASTEXITCODE로 직전 종료 코드를 읽는다.
- 준비기가 /tmp에 자신의 가상 파일·디렉터리·링크를 만들고 정상·오류 시 그 임시 폴더만 정리한다. 수집기에 운영 경로를 전달하지 않는다. Windows 드라이브의 모드를 Linux 모드 실측으로 사용하지 않는다.
