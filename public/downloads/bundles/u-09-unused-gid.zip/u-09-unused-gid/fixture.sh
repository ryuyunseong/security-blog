(
    work=$(mktemp -d) || exit 2

    # 이 예제에서 만든 가상 파일만 정리한다.
    cleanup() {
        rm -f -- "$work/passwd" "$work/group"
        rmdir -- "$work"
    }
    trap cleanup EXIT

    cat > "$work/passwd" <<'EOF'
root:x:0:0::/root:/bin/sh
alice:x:1000:1000::/home/alice:/bin/sh
EOF

    cat > "$work/group" <<'EOF'
root:x:0:
alice:x:1000:
share:x:2000:alice
oldapp:x:3000:
EOF

    # 종료 코드 1도 비교를 완료한 결과이므로 값을 따로 기록한다.
    if python3 check_u09.py --passwd "$work/passwd" --group "$work/group"
    then
        result=0
    else
        result=$?
    fi

    printf '종료 코드: %s\n' "$result"
    exit "$result"
)
