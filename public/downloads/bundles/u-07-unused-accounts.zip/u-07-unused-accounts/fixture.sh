(
    # 임시 디렉터리를 만들지 못하면 바로 중단한다.
    work=$(mktemp -d) || exit 2

    cat > "$work/passwd" <<'EOF'
root:x:0:0:관리자:/root:/bin/bash
svc:x:990:990:서비스:/srv/svc:/usr/sbin/nologin
oldvendor:x:1201:1201:외부인력:/home/oldvendor:/bin/bash
EOF

    cat > "$work/approved.txt" <<'EOF'
root
svc
EOF

    # 종료 코드 1도 정상적인 비교 결과이므로 값을 따로 기록한다.
    if python3 check_u07.py \
        --passwd "$work/passwd" \
        --approved "$work/approved.txt"
    then
        status=0
    else
        status=$?
    fi
    printf '종료 코드: %s\n' "$status"

    # 이 예제에서 만든 가상 파일만 삭제한다.
    rm -- "$work/passwd" "$work/approved.txt"
    rmdir -- "$work"
)
