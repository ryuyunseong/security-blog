# U-32: 홈 디렉토리로 지정한 디렉토리의 존재 관리

본문: https://ryuyunseong.github.io/security-blog/posts/u-32-home-directory-existence/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows Python 3.12.1의 PowerShell·Git Bash에서 검증했다. 일반 사용자에게 쓰기 가능한 OS 임시 폴더가 필요하다. 관리자 권한·별도 패키지·Linux 파일시스템·실제 계정 자료는 필요하지 않다. Windows 실행은 Unix 권한·로그인 검증이 아니다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-32-home-directory-existence
```

## 포함 파일

- `u32_home_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u32_home_lab.py --case all
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u32_home_lab.py --case all
echo $?
```

예상 종료 코드: 0. 기대 상태10건 일치와 임시 자료 정리 완료. 디렉터리 존재2·부재 후보1·종류 확인1·보류6이며 missing 행은 부재 후보다. 종료0은 가상 실습의 기대값 비교 성공이며 양호 계정10건이 아니다.

## 실행 조건과 정리

- 빈 폴더에 ZIP을 풀고 README.md·u32_home_lab.py가 함께 있는 글별 폴더에서 사용하는 셸의 블록 하나를 선택한다. 별도 입력 파일이나 /home·/srv 폴더를 만들지 않는다.
- PowerShell은 $LASTEXITCODE, Bash는 echo $?로 바로 앞 Python의 숫자 종료 코드를 읽는다. PowerShell의 $?는 성공 여부이며 숫자 코드가 아니다. 바깥 셸을 실행하는 도구의 종료 코드와 구분한다.
- 프로그램이 OS 임시 폴더 아래 자신만의 u32-home- 폴더 안에 home/alpha·srv/worker 디렉터리와 home/not-dir 일반 파일을 만든다. 정상·예외 경로에서 이 폴더만 정리를 시도하며 ZIP을 푼 원본 폴더는 남긴다. 정리 오류라면 이 임시 폴더와 잠근 프로그램을 살핀다.
- 미수집·조회 오류는 가상 입력이며 실제 접근 거부를 만들지 않는다. 실제 계정·인증·홈·권한을 조회하거나 변경하지 않는다. 링크·재분석 지점도 준비하지 않는다.
- 종료1은 기대 상태 또는 정리 검증 불일치, 종료2는 잘못된 --case·Python 버전·바깥으로 전달된 임시 준비/정리 실행 오류다. 경로 조회의 OSError는 행의 보류이며 고정 기대값과 어긋나면 종료1이다. 오류는 표준 오류에 나오며 중간 출력이 있으면 종료 코드와 함께 읽는다. 각 행의 보류 자체는 프로그램 오류가 아니다.
