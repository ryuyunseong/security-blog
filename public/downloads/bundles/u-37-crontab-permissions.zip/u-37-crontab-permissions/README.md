# U-37: crontab 설정파일 권한 설정 미흡

본문: https://ryuyunseong.github.io/security-blog/posts/u-37-crontab-permissions/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows PowerShell과 Git Bash에서 검증했다. 가상 JSON의 정수·문자열만 비교하므로 Linux 파일시스템·관리자 권한·cron/at 설치·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-37-crontab-permissions
```

## 포함 파일

- `u37_mode_review.py`
- `u37_mode_cases.json`
- `u37_rejected.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u37_mode_review.py u37_mode_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u37_mode_review.py u37_mode_cases.json
echo $?
```

예상 종료 코드: 0. 가상 자료10건: 일반 권한 범위 내3·검토 후보3·보류4. 종료0은 입력 검사·비교 완료이며 cron 사용 허용이나 U-37 운영 양호 판정이 아니다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u37_mode_review.py u37_rejected.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u37_mode_review.py u37_rejected.json
echo $?
```

예상 종료 코드: 2. 표준 출력은 가상 권한 비교 미실행, 표준 오류는 입력 오류 안내다. 종료2는0680의 예상한 거부이며 입력 허용 결과가 아니다.

## 실행 조건과 정리

- ZIP을 빈 폴더에 풀고 README와 세 파일이 있는 글별 폴더에서 사용하는 셸의 블록 하나를 선택한다. 두 JSON은 이미 포함되므로 다시 생성하지 않는다.
- path는 가상 경로 문자열이다. /etc나 /usr 아래 파일·폴더를 만들지 않는다. 프로그램은 지정한 JSON만 읽고 path의 파일을 열거나 모드를 수집하지 않는다.
- collected는 메타데이터를 얻었다는 가정이다. absent·query-error·uncollected는 실제 운영 부재·권한 오류를 재현한 기록이 아니며 uid·mode를 null로 두고 보류한다.
- 프로그램은 임시 파일·소켓을 만들거나 운영 계정·인증·권한·cron/at를 조회·변경하지 않는다. 실제 crontab/at 명령이나 작업 등록을 실행하지 않는다. ZIP과 입력은 그대로 남긴다.
- 일반 파일 메타데이터만 가정한다. 파일 종류·링크·ACL·그룹과 구성원·접근 제어·실행 상태는 별도 자료이며 특수 비트도 추가 조사로 남긴다. 공식640 경계 중첩을 이 계산으로 확정하지 않는다.
