# U-41: 불필요한 automountd 제거

본문: https://ryuyunseong.github.io/security-blog/posts/u-41-unnecessary-automountd/

## 준비

Python 3.12와 표준 라이브러리. Windows에서 PowerShell과 Git Bash로 실행했어요. Unix 파일시스템이나 관리자 권한, automountd 설치는 필요하지 않아요.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-41-unnecessary-automountd
```

## 포함 파일

- `u41_process_names.py`
- `u41_cases.json`
- `u41_rejected.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u41_process_names.py u41_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u41_process_names.py u41_cases.json
echo $?
```

예상 종료 코드: 0. 아홉 사례에서 이름 후보 4건, 대상 이름 없음 1건, 해석 보류 4건을 출력해요. 종료 0은 가상 이름 대조를 끝냈다는 뜻이에요.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u41_process_names.py u41_rejected.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u41_process_names.py u41_rejected.json
echo $?
```

예상 종료 코드: 2. 표준 출력에 가상 프로세스 이름 대조 미실행, 표준 오류에 PID 범위 또는 중복 오류예요가 나와요. 같은 사례의 중복 PID를 거부한 종료 코드는 2예요.

## 실행 조건과 정리

- ZIP을 빈 폴더에 풀고 README.md, Python 코드와 두 JSON 파일이 같이 있는 폴더로 이동하세요. 각 단계에서 사용하는 셸의 명령 블록 하나를 선택하세요.
- 프로그램은 지정한 JSON만 읽어요. 임시 파일·서비스·마운트를 만들지 않으므로 따로 정리할 대상이 없어요.
- 정상 입력에서 종료 코드 2가 나오면 표준 오류와 함께 현재 폴더와 파일명, UTF-8 JSON의 형식, PID와 키 중복을 살펴보세요. 가상 이름 후보는 실제 실행 파일의 식별이나 서비스 판정과는 범위가 달라요.
