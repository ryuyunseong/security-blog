# U-36: r 계열 서비스 비활성화

본문: https://ryuyunseong.github.io/security-blog/posts/u-36-r-services/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows PowerShell과 Git Bash에서 검증했다. 관리자 권한·inetd 설치·Linux 파일시스템·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-36-r-services
```

## 포함 파일

- `u36_inetd_review.py`
- `u36_sample.conf`
- `u36_malformed.conf`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u36_inetd_review.py --collection collected u36_sample.conf
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u36_inetd_review.py --collection collected u36_sample.conf
echo $?
```

예상 종료 코드: 0. 가상 파일 내 활성 후보 서비스2·주석만1·rsync 별도 조사1. 종료0은 입력 검사·비교 완료이며 운영 양호 판정이 아니다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u36_inetd_review.py --collection uncollected
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u36_inetd_review.py --collection uncollected
echo $?
```

예상 종료 코드: 0. uncollected 보류, 비교 미실행. 종료0은 가정한 미수집 상태 처리이며 서비스 부재를 뜻하지 않는다.

### 3

#### PowerShell

```powershell
python -I -B -X utf8 u36_inetd_review.py --collection query-error
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u36_inetd_review.py --collection query-error
echo $?
```

예상 종료 코드: 0. query-error 보류, 비교 미실행. 종료0은 가정한 오류 상태 처리이며 실제 파일 접근 오류를 재현한 것은 아니다.

### 4

#### PowerShell

```powershell
python -I -B -X utf8 u36_inetd_review.py --collection absent
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u36_inetd_review.py --collection absent
echo $?
```

예상 종료 코드: 0. absent 보류, 비교 미실행. 종료0은 가정한 파일 부재 상태 처리이며 서비스 미사용 판정이 아니다.

### 5

#### PowerShell

```powershell
python -I -B -X utf8 u36_inetd_review.py --collection collected u36_malformed.conf
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u36_inetd_review.py --collection collected u36_malformed.conf
echo $?
```

예상 종료 코드: 2. 표준 출력은 가상 설정 비교 미실행, 표준 오류는 입력 오류 안내다. 종료2는 필드 부족 입력의 예상한 거부이며 입력 허용 결과가 아니다.

## 실행 조건과 정리

- ZIP을 빈 폴더에 풀고 README와 세 파일이 있는 글별 폴더에서 사용하는 셸의 블록 하나를 선택한다. 두 .conf는 이미 포함되므로 다시 생성하지 않는다.
- 설정의 서버 경로는 가상 문자열이다. 해당 프로그램이나 /etc 아래 파일·폴더를 만들지 않는다. 서버 경로를 실행하거나 네트워크에 접속하지 않는다.
- absent·query-error·uncollected는 실제 운영 자료 수집이 아닌 가정이다. 이 상태에서는 파일 인수를 받지 않고 비교를 보류한다.
- 가상 입력 전용 형식만 지원한다. 7개 이상 필드, shell·login·exec·rsync, stream, tcp·tcp4·tcp6, nowait, root, 절대 서버 경로 조건을 벗어나면 거부한다. 전체 inetd 파서가 아니다.
- 코드는 입력 파일만 읽고 임시 파일·소켓을 만들거나 운영 설정·서비스·계정·인증을 조회·변경하지 않는다. ZIP과 원본은 그대로 남긴다.
