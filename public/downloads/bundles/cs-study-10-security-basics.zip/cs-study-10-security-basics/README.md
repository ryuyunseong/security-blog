# 정보보안 기초: HMAC, 접근 권한과 SQL 입력의 차이

본문: https://ryuyunseong.github.io/security-blog/posts/cs-study-10-security-basics/

## 준비

Python 3.9 이상과 표준 라이브러리 sqlite3. Windows Python 3.12.1·SQLite 3.43.1에서 검증했다. 관리자 권한·서버·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cs-study-10-security-basics
```

## 포함 파일

- `10-security-models.py`
- `10-security-questions.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 10-security-models.py mac
echo $?
```

예상 종료 코드: 0. mac은 RFC 태그와 원문 True·변조 False, access는 미인증 거부·소유자 허용·다른 독자 거부·관리자 허용, sql은 정상 이름과 주입 모양 입력을 비교한다. 문제 파일은 문제 2~4를 대조한다. 정상 종료는 0, 처리하지 않은 예외·assert 실패는 1이다.

### 2

```bash
python3 -I -B -X utf8 10-security-models.py access
echo $?
```

예상 종료 코드: 0. mac은 RFC 태그와 원문 True·변조 False, access는 미인증 거부·소유자 허용·다른 독자 거부·관리자 허용, sql은 정상 이름과 주입 모양 입력을 비교한다. 문제 파일은 문제 2~4를 대조한다. 정상 종료는 0, 처리하지 않은 예외·assert 실패는 1이다.

### 3

```bash
python3 -I -B -X utf8 10-security-models.py sql
echo $?
```

예상 종료 코드: 0. mac은 RFC 태그와 원문 True·변조 False, access는 미인증 거부·소유자 허용·다른 독자 거부·관리자 허용, sql은 정상 이름과 주입 모양 입력을 비교한다. 문제 파일은 문제 2~4를 대조한다. 정상 종료는 0, 처리하지 않은 예외·assert 실패는 1이다.

### 4

```bash
python3 -I -B -X utf8 10-security-questions.py
echo $?
```

예상 종료 코드: 0. mac은 RFC 태그와 원문 True·변조 False, access는 미인증 거부·소유자 허용·다른 독자 거부·관리자 허용, sql은 정상 이름과 주입 모양 입력을 비교한다. 문제 파일은 문제 2~4를 대조한다. 정상 종료는 0, 처리하지 않은 예외·assert 실패는 1이다.

## 실행 조건과 정리

- 빈 폴더에 압축을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 두 Python 파일을 같은 폴더에 둔다.
- Linux/WSL에서는 위 python3 명령을 사용한다. Windows PowerShell에서 전산 예제를 실행할 때는 python3 대신 python을 사용할 수 있다. Bash는 echo $?, PowerShell은 $LASTEXITCODE로 직전 종료 코드를 읽는다.
- 문제 파일은 __file__ 옆의 모형을 경로로 읽어 -I에서도 동작한다. assert가 있으므로 -O를 붙이지 않는다. DB는 호출마다 메모리에 다시 만들고 연결을 닫는다. 파일·계정·서버를 만들거나 정리할 필요가 없다.
