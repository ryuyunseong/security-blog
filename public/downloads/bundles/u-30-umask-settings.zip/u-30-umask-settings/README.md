# U-30: UMASK 설정 관리, 설정값과 실행값 대조하기

본문: https://ryuyunseong.github.io/security-blog/posts/u-30-umask-settings/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1, PowerShell과 Git Bash에서 검증했다. 관리자 권한·별도 패키지·Linux 파일시스템이 필요하지 않다. 실제 Unix 설정과 권한은 조회·변경하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-30-umask-settings
```

## 포함 파일

- `u30_umask_review.py`
- `u30_umask_cases.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u30_umask_review.py u30_umask_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u30_umask_review.py u30_umask_cases.json
echo $?
```

예상 종료 코드: 0. 가상 자료 10건. 7건은 설정·실행 출처를 표시해 계산하고 조회 오류·설정 파일 부재·자료 미수집 3건은 보류한다. 0031은 022 이상, 쓰기 차단 누락0002, 파일0646·디렉터리0746이다. 종료0은 가상 계산 완료다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u30_umask_review.py --self-test
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u30_umask_review.py --self-test
echo $?
```

예상 종료 코드: 0. 계산 사례 7건 일치, 입력 거부 12건 일치. 종료0은 기대값 대조 완료이며 서버 상태 판정이 아니다. 기대와 다르면 예외로 중단한다.

## 실행 조건과 정리

- 빈 폴더에 ZIP을 풀고 이 README와 Python·JSON이 있는 글별 폴더에서 실행한다. 각 단계의 PowerShell 또는 Bash 블록 하나만 선택한다. 포함된 JSON을 다시 만들지 않는다.
- PowerShell의 $LASTEXITCODE와 Bash의 echo $?는 바로 앞 Python의 숫자 종료 코드다. PowerShell의 $?는 성공 여부이며 숫자 코드가 아니다. 바깥 셸을 실행한 도구의 종료 코드와도 구분한다.
- 첫 명령에는 입력 경로를 주고 --self-test에는 경로를 주지 않는다. 공백이 있는 입력 경로는 따옴표로 감싼다. 읽기·JSON·필드 검증 오류는 표준 오류와 종료2다.
- 기본 ACL 없는 신규 생성 권한만 정수로 계산한다. 파일 생성·umask 변경·실제 수집은 하지 않는다. 결과 파일을 쓰지 않으며 정리 대상은 자신이 압축을 푼 폴더뿐이다.
