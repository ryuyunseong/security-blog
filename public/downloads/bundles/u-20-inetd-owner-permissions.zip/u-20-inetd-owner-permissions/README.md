# U-20: /etc/(x)inetd.conf 파일 소유자 및 권한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-20-inetd-owner-permissions/

## 준비

Python 3.9 이상과 표준 라이브러리. 검증 환경은 Python 3.12.1이다. 별도 패키지·서버·관리자 권한은 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-20-inetd-owner-permissions
```

## 포함 파일

- `u20_superdaemon_records.py`
- `u20_superdaemon_samples.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u20_superdaemon_records.py u20_superdaemon_samples.json
echo $?
```

예상 종료 코드: 0. 가상 자료 7건을 비교하고 끝난다. 권한 차이나 추가 조사 항목이 있어도 비교 완료의 종료 코드는 0이며, 입력 오류는 2다.

## 실행 조건과 정리

- JSON은 포함된 가상 자료다. 실제 서비스 설정 파일·계정·권한·ACL은 읽거나 변경하지 않는다.
- 입력 JSON이 이미 들어 있으므로 다시 만들지 않는다. 인수 생략 시 실제 시스템 경로로 넘어가지 않는다.
- Windows에서는 python3를 python으로 바꾸고 명령 직후 $LASTEXITCODE로 종료 코드를 읽는다.
- 생성 파일이 없으며 자료는 프로세스 종료와 함께 정리된다. 별도 삭제 명령은 필요하지 않다.
