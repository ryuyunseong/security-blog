# TLS 1.3이면 안전할까? 버전과 인증서 검증의 차이

본문: https://ryuyunseong.github.io/security-blog/posts/tls-version-and-identity/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다. OpenSSL 3.x 명령줄 도구와 TLS 1.3을 지원하는 Python ssl 라이브러리가 필요하다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd tls-version-and-identity
```

## 포함 파일

- `tls_identity_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B tls_identity_lab.py
echo $?
```

예상 종료 코드: 0. 성공=4 실패=0 전체=4와 임시 인증서·비밀키 정리: 성공이 나온다. 성공에는 예상한 인증서 거절 두 건도 포함된다.

## 실행 조건과 정리

- 인증서·키는 코드가 임시 폴더에 생성하고 지운다. 운영체제 신뢰 저장소는 바꾸지 않으며 서버는 127.0.0.1의 임의 포트만 사용한다.
