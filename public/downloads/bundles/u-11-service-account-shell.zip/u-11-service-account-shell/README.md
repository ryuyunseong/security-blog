# U-11: 사용자 shell 점검

본문: https://ryuyunseong.github.io/security-blog/posts/u-11-service-account-shell/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-11-service-account-shell
```

## 포함 파일

- `check_u11_demo.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B check_u11_demo.py
echo $?
```

예상 종료 코드: 0. 본문의 가상 예제 출력이 나오며 기대값 검사가 통과한다. 출력의 판정은 가상 입력 범위다.
