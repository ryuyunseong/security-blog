# U-44: tftp, talk 서비스 비활성화

본문: https://ryuyunseong.github.io/security-blog/posts/u-44-tftp-talk-services/

## 준비

Python 3.12와 표준 라이브러리. Windows에서 PowerShell과 Git Bash로 검증했어요. 현재 폴더에서 실행하며 관리자 권한이나 서비스 설치는 필요 없어요.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-44-tftp-talk-services
```

## 포함 파일

- `u44_service_rows.py`
- `u44_samples.json`
- `u44_duplicate.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u44_service_rows.py u44_samples.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u44_service_rows.py u44_samples.json
echo $?
```

예상 종료 코드: 0. short, full, quiet 순으로 세 줄이 나와요. short에서 talk는 no-row, ntalk는 query-error예요. 종료 코드 0은 세 묶음의 대조를 마쳤다는 뜻이에요.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u44_service_rows.py u44_duplicate.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u44_service_rows.py u44_duplicate.json
echo $?
```

예상 종료 코드: 2. 표준 출력은 samples-emitted=0이고 표준 오류에는 duplicate service: talk가 남아요. 중복 행을 거부하면 종료 코드는 2예요.

## 실행 조건과 정리

- ZIP을 빈 폴더에 푼 뒤 README.md와 Python 코드, 두 JSON 파일이 있는 폴더에서 실행하세요. 각 단계에서 사용하는 셸의 명령을 선택하세요.
- 실제 서비스와 네트워크에 연결하지 않고 지정한 JSON만 읽어요. 정상 입력에서 오류가 나면 파일명과 현재 폴더, 서비스 이름과 상태 표기를 살펴보세요.
