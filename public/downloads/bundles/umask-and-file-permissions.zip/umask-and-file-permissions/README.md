# umask 설정과 실제 파일 권한

본문: https://ryuyunseong.github.io/security-blog/posts/umask-and-file-permissions/

## 준비

Linux 또는 WSL의 Bash, Python 3.12, libacl 공유 라이브러리. /tmp가 POSIX ACL을 지원하고 /proc/self/status에 Umask 항목이 있어야 한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd umask-and-file-permissions
```

## 포함 파일

- `umask_lab.sh`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
bash umask_lab.sh
echo $?
```

예상 종료 코드: 0. umask·요청 모드·기본 ACL 비교가 통과하고 실습 임시 폴더와 생성 파일 삭제가 나온다.

## 실행 조건과 정리

- 실습 파일은 기본적으로 /tmp에 만든다. ACL 미지원 오류는 본문의 파일시스템 진단 절차를 따른다. sudo만으로 ACL 미지원이 해결되지는 않는다.
