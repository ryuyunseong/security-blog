# U-23: SUID, SGID, Sticky bit 설정 파일 점검

본문: https://ryuyunseong.github.io/security-blog/posts/u-23-special-permission-bits/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1에서 검증했다. 관리자 권한·서버·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-23-special-permission-bits
```

## 포함 파일

- `u23_special_bits.py`
- `u23_special_bits.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u23_special_bits.py u23_special_bits.json
echo $?
```

예상 종료 코드: 0. 7건 분류와 검색 조건 3건을 출력한다. 종료 0은 분류 완료이며 실제 파일의 양호 판정은 아니다. 읽기·형식 오류는 2다.

## 실행 조건과 정리

- 빈 폴더에 압축을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 입력은 이미 포함되어 있다.
- Windows PowerShell에서는 python3 대신 python을 사용할 수 있다. 명령 직후 $LASTEXITCODE, Bash에서는 echo $?로 종료 코드를 읽는다.
- 지정한 가상 JSON만 읽는다. 운영 파일·파일 속성·계정은 조회하거나 바꾸지 않는다. 입력 파일명과 네 자리 8진수 문자열을 살핀다. 출력 파일이나 정리할 임시 자료는 만들지 않는다.
