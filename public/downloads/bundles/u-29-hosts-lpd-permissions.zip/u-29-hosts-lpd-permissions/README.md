# U-29: hosts.lpd 파일 소유자 및 권한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-29-hosts-lpd-permissions/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1에서 검증했다. 관리자 권한·별도 패키지·Linux 파일시스템·실제 hosts.lpd가 필요하지 않다. UID·모드는 가상 값으로만 계산한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-29-hosts-lpd-permissions
```

## 포함 파일

- `u29_lpd_evidence.py`
- `u29_lpd_cases.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u29_lpd_evidence.py cases u29_lpd_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u29_lpd_evidence.py cases u29_lpd_cases.json
echo $?
```

예상 종료 코드: 0. 가상 자료 10건. root-600·root-400은 입력된 기본 조건 일치, 부재는 비교 생략, 미수집·링크는 보류다. 종료0은 계산 완료다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u29_lpd_evidence.py modes
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u29_lpd_evidence.py modes
echo $?
```

예상 종료 코드: 0. 일반 권한 512개 중 숫자 비교 385개, 비트 조건 4개, 차이 381개다. 일치 모드는 0000·0200·0400·0600이며 종료0은 열거 완료다.

## 실행 조건과 정리

- 빈 폴더에 ZIP을 풀고 이 README가 있는 글별 폴더에서 두 명령을 각각 실행한다. Python 파일과 JSON을 같은 폴더에 두며 포함된 입력을 다시 만들지 않는다.
- PowerShell에서는 python을 실행하고 명령 직후 $LASTEXITCODE로 종료 코드를 읽는다. Linux·WSL에서는 python3와 명령 직후 echo $?를 사용할 수 있다.
- 직접 지정하는 입력 경로에 공백이 있으면 따옴표로 감싼다. cases에는 JSON 경로가 필요하고 modes에는 파일을 주지 않는다.
- 읽기·JSON·필드 오류는 표준 오류와 종료2다. 상태별 필드, UID 정수, 네 자리 8진수 모드, required의 true·false·null을 살핀다.
- 실제 파일·계정·권한·프린트 서비스를 조회하거나 변경하지 않고 결과 파일도 쓰지 않는다. 정리 대상은 자신이 압축을 푼 실습 폴더뿐이다.
