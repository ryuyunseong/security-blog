# C·Java·Python 출력 문제: 나눗셈과 변수 변경 따라가기

본문: https://ryuyunseong.github.io/security-blog/posts/cs-study-06-programming-basics/

## 준비

Python 3.9 이상, C11을 지원하는 gcc, Java의 javac·java가 있는 JDK 17 이상. 언어별 도구는 실행할 터미널 PATH에 있어야 한다. 별도 Python 패키지·서버·계정은 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cs-study-06-programming-basics
```

## 포함 파일

- `06-run-examples.py`
- `06-programming-basics.c`
- `ProgrammingBasics.java`
- `06-programming-basics.py`
- `06-question1.c`
- `Question2.java`
- `06-question3.py`
- `06-question4.c`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 06-run-examples.py c
echo $?
```

예상 종료 코드: 0. 선택한 언어의 소스를 실행하고 stdout을 기대값과 대조한다. 컴파일·프로그램 종료 0과 빈 stderr도 요구하며 실패하면 도우미는 2로 끝난다.

### 2

```bash
python3 -I -B -X utf8 06-run-examples.py java
echo $?
```

예상 종료 코드: 0. 선택한 언어의 소스를 실행하고 stdout을 기대값과 대조한다. 컴파일·프로그램 종료 0과 빈 stderr도 요구하며 실패하면 도우미는 2로 끝난다.

### 3

```bash
python3 -I -B -X utf8 06-run-examples.py python
echo $?
```

예상 종료 코드: 0. 선택한 언어의 소스를 실행하고 stdout을 기대값과 대조한다. 컴파일·프로그램 종료 0과 빈 stderr도 요구하며 실패하면 도우미는 2로 끝난다.

### 4

```bash
python3 -I -B -X utf8 06-run-examples.py c --questions
echo $?
```

예상 종료 코드: 0. 선택한 언어의 소스를 실행하고 stdout을 기대값과 대조한다. 컴파일·프로그램 종료 0과 빈 stderr도 요구하며 실패하면 도우미는 2로 끝난다.

### 5

```bash
python3 -I -B -X utf8 06-run-examples.py java --questions
echo $?
```

예상 종료 코드: 0. 선택한 언어의 소스를 실행하고 stdout을 기대값과 대조한다. 컴파일·프로그램 종료 0과 빈 stderr도 요구하며 실패하면 도우미는 2로 끝난다.

### 6

```bash
python3 -I -B -X utf8 06-run-examples.py python --questions
echo $?
```

예상 종료 코드: 0. 선택한 언어의 소스를 실행하고 stdout을 기대값과 대조한다. 컴파일·프로그램 종료 0과 빈 stderr도 요구하며 실패하면 도우미는 2로 끝난다.

## 실행 조건과 정리

- 검증 환경: C는 WSL Ubuntu 24.04 / GCC 13.3.0 / Python 3.12.3, Java는 Windows JDK 25 / Python 3.12.1, Python 예제는 Windows Python 3.12.1.
- Windows에서 C는 GCC가 있는 WSL/Linux 터미널에서 실행한다. 본문에 현재 폴더 경로를 WSL 경로로 변환하는 선택 명령이 있다. Java·Python은 Windows에서 python3를 python으로 바꿔 실행할 수 있다.
- --questions 명령과 도우미의 기대 문자열에는 풀이가 들어 있다. 문제를 푼 뒤 실행한다. 문제 5는 명세 비교이며 실행 결과를 생성하지 않는다.
- ZIP에 포함된 파일을 다시 만들 필요는 없다. 빈 폴더에 압축을 풀고 소스와 도우미를 함께 둔다.
- Windows PowerShell에서는 명령 직후 $LASTEXITCODE로 종료 코드를 읽는다.
- C·Java 컴파일 결과는 실행이 만든 임시 폴더에만 저장하고 정상·실패 시 정리한다. 원본 소스는 바꾸지 않는다.
