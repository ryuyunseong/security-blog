(
    work=$(mktemp -d) || exit 2

    # 예제에서 만든 두 파일만 정리한다.
    cleanup() {
        rm -f -- "$work/passwd" "$work/group"
        rmdir -- "$work"
    }
    trap cleanup EXIT

    cat > "$work/passwd" <<'EOF'
root:x:0:0::/root:/bin/sh
deploy:x:1001:0::/srv/deploy:/bin/sh
audit:x:1002:1002::/home/audit:/bin/sh
EOF

    cat > "$work/group" <<'EOF'
root:x:0:audit
audit:x:1002:
EOF

    # 종료 코드 1도 비교를 완료한 결과이므로 값을 따로 기록한다.
    if python3 check_u08.py \
        --passwd "$work/passwd" \
        --group-file "$work/group" \
        --allow root
    then
        result=0
    else
        result=$?
    fi

    printf '종료 코드: %s\n' "$result"
    exit "$result"
)
