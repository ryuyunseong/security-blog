# 파일 다운로드 경로 검증: 상위 경로와 심볼릭 링크 검사

본문: https://ryuyunseong.github.io/security-blog/posts/download-path-validation/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd download-path-validation
```

## 포함 파일

- `path_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B path_lab.py
echo $?
```

예상 종료 코드: 0. 본문의 가상 예제 출력이 나오고 내부 기대값 검사가 통과한다.

## 실행 조건과 정리

- 심볼릭 링크를 만들 수 있는 Linux 파일시스템이 필요하다. 시험 파일과 링크는 임시 폴더 안에 만들고 정리하며 /app/files를 직접 만들 필요는 없다.
