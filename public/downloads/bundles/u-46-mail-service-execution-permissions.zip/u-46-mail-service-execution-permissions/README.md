# U-46: 일반 사용자의 메일 서비스 실행 방지

본문: https://ryuyunseong.github.io/security-blog/posts/u-46-mail-service-execution-permissions/

## 준비

Python 3.12와 표준 라이브러리. Windows의 PowerShell과 Git Bash에서 검증했어요. 메일 서버나 관리자 권한은 필요 없어요.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-46-mail-service-execution-permissions
```

## 포함 파일

- `u46_mode_record.py`
- `u46_modes.txt`
- `u46_invalid.txt`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u46_mode_record.py u46_modes.txt
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u46_mode_record.py u46_modes.txt
echo $?
```

예상 종료 코드: 0. 네 줄의 other-x 값이 set, clear, unknown, unknown 순서로 나와요. 종료 코드 0은 네 행을 처리했다는 뜻이에요.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u46_mode_record.py u46_invalid.txt
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u46_mode_record.py u46_invalid.txt
echo $?
```

예상 종료 코드: 2. 둘째 줄에서 8진수 모드 형식 오류가 표준 오류에 표시돼요. 표준 출력에는 records-emitted=0이 나오고 종료 코드는 2예요.

## 실행 조건과 정리

- 빈 폴더에 풀고 README.md, 코드, 두 입력 파일이 들어 있는 폴더에서 실행하세요. 각 단계에서 사용하는 셸의 블록 하나를 선택하세요.
- 모드는 상태가 observed일 때만 해석해요. read-error와 not-collected에서는 모드 자리에 -를 적어요.
