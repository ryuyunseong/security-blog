# 작은 gzip 파일도 안전하지 않다: 압축 해제 출력량 제한하기

본문: https://ryuyunseong.github.io/security-blog/posts/gzip-output-limit/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd gzip-output-limit
```

## 포함 파일

- `gzip_limit.py`
- `sample.gz`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B gzip_limit.py
echo $?
```

예상 종료 코드: 0. 메모리의 정상·초과·형식 오류 예제를 비교하고 예상한 거부도 성공으로 표시한다.

### 2

```bash
python3 -I -B gzip_limit.py ./sample.gz --limit 65536
echo $?
```

예상 종료 코드: 0. “검사 완료: 출력 65536바이트, 설정한 정책 범위 내”가 나온다.

### 3

```bash
python3 -I -B gzip_limit.py ./sample.gz --limit 65535
echo $?
```

예상 종료 코드: 1. 표준 오류에 정책상 거부: 압축 해제 출력 한도 초과가 나온다.

## 실행 조건과 정리

- sample.gz는 A 65,536바이트를 압축한 가상 입력이다. 해제 내용을 디스크에 저장하지 않는다. ZIP에 이미 들어 있으므로 본문의 파일 생성 명령은 다시 실행하지 않는다.

종료 코드 1이 예상된 단계는 차이나 정책 거부를 재현하는 실습이다. 해당 단계의 기대 출력과 함께 읽는다.
