# U-31: 홈디렉토리 소유자 및 권한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-31-home-owner-permissions/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1의 PowerShell·Git Bash에서 검증했다. 관리자 권한·별도 패키지·Linux 파일시스템·실제 계정이나 홈 폴더가 필요하지 않다. JSON의 Unix 경로는 문자열로만 사용한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-31-home-owner-permissions
```

## 포함 파일

- `u31_home_review.py`
- `u31_home_cases.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u31_home_review.py u31_home_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u31_home_review.py u31_home_cases.json
echo $?
```

예상 종료 코드: 0. 가상 자료12건: 입력 조건 일치1·검토 후보5·보류6. group-write는 UID=1002/소유=1002, mode=0770이며 일반모드 쓰기0020이 검토 후보로 남는다. 종료0은 가상 자료의 형식 검사와 분류 완료다.

## 실행 조건과 정리

- 빈 폴더에 ZIP을 풀고 README와 Python·JSON이 함께 있는 글별 폴더에서 실행한다. 사용하는 셸의 실행 블록 하나를 선택하며 포함된 JSON은 다시 만들지 않는다.
- PowerShell은 $LASTEXITCODE, Bash는 echo $?로 바로 앞 Python의 숫자 종료 코드를 읽는다. PowerShell의 $?는 성공 여부이며 숫자 코드가 아니다. 바깥 셸을 실행하는 도구의 종료 코드와 구분한다.
- 입력 경로에 공백이 있으면 전체 경로를 따옴표로 감싼다. 읽기·JSON·필드·UID·경로·상태별 메타데이터 오류는 표준 오류와 종료2다. 부분 결과는 출력하지 않는다.
- 실제 계정·홈 폴더·권한·ACL을 조회하거나 변경하지 않는다. /home/bravo 등 JSON 경로에 폴더를 만들 필요가 없다. 결과 파일을 쓰지 않으며 정리 대상은 자신이 ZIP을 푼 폴더뿐이다.
