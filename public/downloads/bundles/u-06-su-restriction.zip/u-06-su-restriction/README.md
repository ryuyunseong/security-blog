# U-06: 사용자 계정 su 기능 제한

본문: https://ryuyunseong.github.io/security-blog/posts/u-06-su-restriction/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다. 파일 소유자·모드를 읽으므로 Linux 파일시스템에서 실행한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-06-su-restriction
```

## 포함 파일

- `check_u06.py`
- `u06_fixture_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B u06_fixture_lab.py ./check_u06.py
echo $?
```

예상 종료 코드: 0. 가상 입력의 수집 코드가 예상값과 일치하고 마지막에 실습 파일 정리: 완료가 나온다.

## 실행 조건과 정리

- 가상 자료를 대상으로 실행하는 명령이다. 수집기를 인자 없이 실행하거나 실제 /etc 경로로 바꾸면 조사 범위가 달라진다.
