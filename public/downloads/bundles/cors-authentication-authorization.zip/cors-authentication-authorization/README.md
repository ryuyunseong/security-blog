# CORS 설정과 서버 접근 권한의 차이

본문: https://ryuyunseong.github.io/security-blog/posts/cors-authentication-authorization/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cors-authentication-authorization
```

## 포함 파일

- `cors_auth_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B cors_auth_lab.py
echo $?
```

예상 종료 코드: 0. 본문의 가상 예제 출력이 나오고 내부 기대값 검사가 통과한다.

## 실행 조건과 정리

- 서버와 클라이언트가 한 번에 실행된다. 127.0.0.1의 임의 포트만 사용하고 끝나면 서버를 닫는다. 실제 토큰이나 브라우저 준비는 필요 없다.
