# U-12: 세션 종료 시간 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-12-session-timeout/

## 준비

Linux 또는 WSL의 Bash와 util-linux의 script 명령, sleep, tr. 가상 터미널을 만들 수 있어야 한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-12-session-timeout
```

## 포함 파일

- `check_u12_idle.sh`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
bash check_u12_idle.sh
echo $?
```

예상 종료 코드: 0. 입력 없는 프롬프트가 TMOUT으로 종료되고 확인: 입력 없는 프롬프트에서 셸 자동 종료가 나온다.

## 실행 조건과 정리

- 일회용 자식 Bash의 TMOUT만 바꾸며 현재 로그인 셸의 설정을 변경하지 않는다. 약 4초가 걸린다.
