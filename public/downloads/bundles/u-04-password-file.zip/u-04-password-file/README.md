# U-04: 비밀번호 파일 보호

본문: https://ryuyunseong.github.io/security-blog/posts/u-04-password-file/

## 준비

Linux 또는 WSL의 Bash, awk와 GNU coreutils. /tmp에 가상 파일을 만들 수 있어야 한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-04-password-file
```

## 포함 파일

- `check_u04_password_file.sh`
- `u04_fixture_lab.sh`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
bash u04_fixture_lab.sh ./check_u04_password_file.sh
echo $?
```

예상 종료 코드: 0. 수집기 코드 0·1·2를 차례로 비교하고 세 경우의 종료 코드 비교: 통과와 실습 파일 정리: 완료가 나온다.

## 실행 조건과 정리

- 가상 자료를 대상으로 실행하는 명령이다. 수집기를 인자 없이 실행하거나 실제 /etc 경로로 바꾸면 조사 범위가 달라진다.
