# 소프트웨어공학: 요구조건을 상태와 테스트 사례로 바꾸기

본문: https://ryuyunseong.github.io/security-blog/posts/cs-study-09-software-engineering/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1에서 검증했다. 관리자 권한·서버·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cs-study-09-software-engineering
```

## 포함 파일

- `09-shipping-rules.py`
- `09-software-questions.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 09-shipping-rules.py fees
echo $?
```

예상 종료 코드: 0. fees는 경계 금액과 범위 거부, states는 결제·배송과 배송 후 취소 거부, 문제 파일은 문제 3~5를 대조한다. 정상 종료는 0이며 처리하지 않은 예외·assert 실패는 1이다.

### 2

```bash
python3 -I -B -X utf8 09-shipping-rules.py states
echo $?
```

예상 종료 코드: 0. fees는 경계 금액과 범위 거부, states는 결제·배송과 배송 후 취소 거부, 문제 파일은 문제 3~5를 대조한다. 정상 종료는 0이며 처리하지 않은 예외·assert 실패는 1이다.

### 3

```bash
python3 -I -B -X utf8 09-software-questions.py
echo $?
```

예상 종료 코드: 0. fees는 경계 금액과 범위 거부, states는 결제·배송과 배송 후 취소 거부, 문제 파일은 문제 3~5를 대조한다. 정상 종료는 0이며 처리하지 않은 예외·assert 실패는 1이다.

## 실행 조건과 정리

- 빈 폴더에 압축을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 입력은 이미 포함되어 있다.
- Windows PowerShell에서는 python3 대신 python을 사용할 수 있다. 명령 직후 $LASTEXITCODE, Bash에서는 echo $?로 종료 코드를 읽는다.
- 두 Python 파일을 같은 폴더에 둔다. 문제 파일은 __file__ 옆의 모형을 경로로 읽어 -I에서도 동작한다. 검증용 assert가 있으므로 -O를 붙이지 않는다. 파일·서버 생성이나 정리 절차는 없다.
