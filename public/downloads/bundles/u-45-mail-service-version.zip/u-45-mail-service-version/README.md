# U-45: 메일 서비스 버전 점검

본문: https://ryuyunseong.github.io/security-blog/posts/u-45-mail-service-version/

## 준비

Python 3.12와 표준 라이브러리. Windows의 PowerShell과 Git Bash에서 검증했어요. 폴더의 UTF-8 텍스트 파일을 읽으며 관리자 권한이나 메일 서버는 필요 없어요.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-45-mail-service-version
```

## 포함 파일

- `u45_package_record.py`
- `u45_inventory.txt`
- `u45_invalid.txt`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u45_package_record.py u45_inventory.txt
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u45_package_record.py u45_inventory.txt
echo $?
```

예상 종료 코드: 0. 다섯 줄의 끝에 match, different, no-reference, read-error, not-collected가 차례로 나와요. 종료 코드 0은 입력 대조를 끝냈다는 뜻이에요.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u45_package_record.py u45_invalid.txt
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u45_package_record.py u45_invalid.txt
echo $?
```

예상 종료 코드: 2. 표준 출력은 records-emitted=0이고 표준 오류는 line 2: missing value must be -를 알려요. 예상 종료 코드는 2예요.

## 실행 조건과 정리

- ZIP을 빈 폴더에 풀고 README.md, Python 코드와 두 텍스트 입력이 있는 폴더에서 실행하세요. 각 단계에서 사용하는 셸의 블록 하나를 선택하세요.
- 입력 한 줄은 경로|수집 상태|설치 버전 순서예요. 설치값을 얻지 못한 행은 마지막 칸에 -를 넣어요. match와 different는 실습 기준표와의 문자열 대조 결과예요.
