(
    work=$(mktemp -d) || exit 2

    # 이 예제에서 만든 가상 파일만 정리한다.
    cleanup() {
        rm -f -- "$work/passwd"
        rmdir -- "$work"
    }
    trap cleanup EXIT

    cat > "$work/passwd" <<'EOF'
root:x:0:0::/root:/bin/sh
deploy:x:1500:1500::/srv/deploy:/bin/sh
backup:x:1500:1600::/srv/backup:/usr/sbin/nologin
EOF

    # 중복 발견에 따른 종료 코드 1도 기록한다.
    if python3 check_u10.py --passwd "$work/passwd"
    then
        result=0
    else
        result=$?
    fi

    printf '종료 코드: %s\n' "$result"
    exit "$result"
)
