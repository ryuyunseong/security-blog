# U-28: 접속 IP 및 포트 제한

본문: https://ryuyunseong.github.io/security-blog/posts/u-28-ip-port-access/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1에서 검증했다. 관리자 권한·별도 패키지·서버·방화벽 도구가 필요하지 않다. 주소와 포트는 가상 JSON 값으로만 비교한다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-28-ip-port-access
```

## 포함 파일

- `u28_access_model.py`
- `u28_access_cases.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python -I -B -X utf8 u28_access_model.py u28_access_cases.json
echo $?
```

예상 종료 코드: 0. 가상 요청 8건: 허용 3건, 거부 5건. blocked-host는 가상 거부, 규칙1=block-one. 정상 계산은 종료0, 입력·읽기 오류는 stderr와 종료2다.

### 2

```bash
python -I -B -X utf8 u28_access_model.py u28_access_cases.json --swap-first-two
echo $?
```

예상 종료 코드: 0. 가상 요청 8건: 허용 4건, 거부 4건. blocked-host는 가상 허용, 규칙1=admin-net. 정상 계산은 종료0, 입력·읽기 오류는 stderr와 종료2다.

## 실행 조건과 정리

- 빈 폴더에 ZIP을 풀고 이 README가 있는 글별 폴더에서 두 명령을 각각 실행한다. Python 파일과 JSON은 같은 폴더에 두고 포함된 입력을 다시 만들지 않는다.
- PowerShell에서 python을 실행하고 명령 직후 $LASTEXITCODE로 종료 코드를 읽는다. Linux·WSL에서는 python3와 명령 직후 echo $?를 사용할 수 있다.
- 입력 파일 경로에 공백이 있으면 따옴표로 감싼다. 입력 오류는 지정한 JSON 경로·필드·CIDR·프로토콜·정수 포트·교환할 규칙 수를 살핀다.
- 두 번째 명령은 JSON을 새로 읽고 메모리에서 첫 두 규칙만 교환한다. 운영 방화벽과 입력 파일은 수정하지 않으며 결과 파일을 쓰지 않는다. 정리 대상은 자신이 압축을 푼 실습 폴더뿐이다.
