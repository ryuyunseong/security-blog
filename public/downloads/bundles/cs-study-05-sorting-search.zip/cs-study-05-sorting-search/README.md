# 정렬과 이진 탐색: 배열이 바뀌는 과정과 경계 읽기

본문: https://ryuyunseong.github.io/security-blog/posts/cs-study-05-sorting-search/

## 준비

Python 3.9 이상과 표준 라이브러리. 검증 환경은 Python 3.12.1이다. 별도 패키지·서버·관리자 권한은 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cs-study-05-sorting-search
```

## 포함 파일

- `05-sorting-search.py`
- `05-sorting-search-questions.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 05-sorting-search.py
echo $?
```

예상 종료 코드: 0. 기대값과 반환 순서를 대조하고 종료 코드 0, 빈 표준 오류로 끝난다. 카운터는 본문이 정의한 연산 수이며 초 단위 측정값이 아니다.

### 2

```bash
python3 -I -B -X utf8 05-sorting-search-questions.py
echo $?
```

예상 종료 코드: 0. 자체 문제 코드 4건을 대조한다. q 번호는 문제 번호이며 점근 표기의 증명은 본문 해설로 읽는다.

## 실행 조건과 정리

- 입력은 코드 안의 작은 자료다. 별도 파일·DB·서버를 준비하지 않는다.
- 문제 검증 파일은 문제를 푼 뒤 실행한다. Python 배열과 연산 카운터만 다룬다.
- Windows에서는 python3를 python으로 바꾸고 명령 직후 $LASTEXITCODE로 종료 코드를 읽는다.
- 생성 파일이 없으며 자료는 프로세스 종료와 함께 정리된다. 별도 삭제 명령은 필요하지 않다.
