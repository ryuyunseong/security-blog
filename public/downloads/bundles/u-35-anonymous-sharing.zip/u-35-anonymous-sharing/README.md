# U-35: 공유 서비스에 대한 익명 접근 제한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-35-anonymous-sharing/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows PowerShell과 Git Bash에서 검증했다. 관리자 권한·vsftpd 설치·Linux 파일시스템·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-35-anonymous-sharing
```

## 포함 파일

- `u35_anonymous_review.py`
- `u35_anonymous_cases.json`
- `u35_rejected.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u35_anonymous_review.py u35_anonymous_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u35_anonymous_review.py u35_anonymous_cases.json
echo $?
```

예상 종료 코드: 0. 가상 설정9건: 명시적 제한값1·검토 후보1·보류7. 종료0은 입력 검사·추출 완료이며 운영 양호 판정이 아니다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u35_anonymous_review.py u35_rejected.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u35_anonymous_review.py u35_rejected.json
echo $?
```

예상 종료 코드: 2. 표준 출력은 가상 설정 비교 미실행, 표준 오류는 text의 null 조건 위반이다. 종료2는 예상한 비교 전 거부이며 입력 허용 결과가 아니다.

## 실행 조건과 정리

- 글별 폴더에서 사용하는 셸의 블록 하나를 선택한다. 두 JSON은 이미 포함되므로 다시 생성하지 않는다.
- 설정 본문은 JSON 안의 가상 문자열이다. 별도 .conf나 /etc 아래 파일을 만들지 않는다. absent·query-error·uncollected는 실제 서버 조회 결과가 아닌 가상 상태다.
- 코드는 지정한 JSON만 읽고 소켓·임시 파일을 만들거나 운영 서비스·계정·설정을 조회·변경하지 않는다. 원본과 ZIP은 그대로 남긴다.
- anonymous_enable 한 항목만 추출하며 전체 vsftpd 구문·기본값·중복 적용·서비스 반영이나 실제 접근을 판정하지 않는다.
