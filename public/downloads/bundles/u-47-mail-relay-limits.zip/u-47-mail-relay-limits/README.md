# U-47: 스팸 메일 릴레이 제한

본문: https://ryuyunseong.github.io/security-blog/posts/u-47-mail-relay-limits/

## 준비

Python 3.12와 표준 라이브러리. Windows의 PowerShell 및 Git Bash에서 실행했어요. 메일 서버와 관리자 권한은 필요 없어요.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-47-mail-relay-limits
```

## 포함 파일

- `u47_relay_ranges.py`
- `u47_ranges.txt`
- `u47_invalid.txt`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u47_relay_ranges.py u47_ranges.txt
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u47_relay_ranges.py u47_ranges.txt
echo $?
```

예상 종료 코드: 0. outside 값은 0, 16, unknown, unknown 순서예요. 숫자 종료 코드 0은 네 사례의 입력을 처리했다는 뜻이에요.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u47_relay_ranges.py u47_invalid.txt
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u47_relay_ranges.py u47_invalid.txt
echo $?
```

예상 종료 코드: 2. 표준 오류에 line 2가 나오고 표준 출력에는 records-emitted=0이 표시돼요. 숫자 종료 코드는 2예요.

## 실행 조건과 정리

- 빈 폴더에 압축을 풀고 README.md, 코드, 두 입력 파일이 있는 폴더에서 각 단계의 셸 블록 하나를 실행하세요.
- 각 줄은 독립된 가상 사례예요. read-error와 not-collected 상태는 값 자리에 -를 사용해요.
