# U-34: Finger 서비스 비활성화

본문: https://ryuyunseong.github.io/security-blog/posts/u-34-finger-service/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows의 PowerShell 또는 Git Bash에서 검증했다. 관리자 권한·별도 패키지·Unix 파일시스템은 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-34-finger-service
```

## 포함 파일

- `u34_finger_review.py`
- `u34_finger_cases.json`
- `u34_rejected.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u34_finger_review.py u34_finger_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u34_finger_review.py u34_finger_cases.json
echo $?
```

예상 종료 코드: 0. 가상 자료10건: 입력 조건 일치2·검토 후보4·보류4. 종료0은 입력 검사·분류 완료이며 운영 양호 판정이 아니다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u34_finger_review.py u34_rejected.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u34_finger_review.py u34_rejected.json
echo $?
```

예상 종료 코드: 2. 표준 출력은 가상 자료 분류 미실행, 표준 오류는 setting의 null 조건 위반이다. 종료2는 예상한 입력 거부이며 실제 허용·양호 결과가 아니다.

## 실행 조건과 정리

- 글별 폴더에서 사용하는 셸의 블록 하나를 선택해 실행한다. JSON 두 개는 이미 포함되어 있으므로 다시 생성하지 않는다.
- xinetd의 yes/no와 inetd의 commented/active, 실행 관찰 상태는 가상 정규화 자료다. 프로그램은 운영 설정이나 소켓을 수집하지 않는다.
- 코드는 지정한 JSON만 읽고 파일을 만들거나 지우지 않는다. 원본·입력·ZIP을 보존하며 잘못된 입력은 경로·UTF-8·JSON·필드와 수집 상태부터 살핀다.
