# U-40: NFS 접근 통제

본문: https://ryuyunseong.github.io/security-blog/posts/u-40-nfs-access-control/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows Python 3.12.1의 PowerShell과 Git Bash에서 검증했다. JSON 문자열·정수만 대조하므로 Linux 파일시스템·관리자 권한·NFS 설치·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-40-nfs-access-control
```

## 포함 파일

- `u40_exports_review.py`
- `u40_cases.json`
- `u40_rejected.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u40_exports_review.py u40_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u40_exports_review.py u40_cases.json
echo $?
```

예상 종료 코드: 0. 가상 자료10건: 제한 표기2·검토 후보4·해석 보류4. 종료0은 입력 검사와 대조 완료다. 제한 표기는 업무상 허가·실제 접근 허용·쓰기 성공 또는 U-40 종합 양호 판정이 아니다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u40_exports_review.py u40_rejected.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u40_exports_review.py u40_rejected.json
echo $?
```

예상 종료 코드: 2. stdout은 가상 exports 대조 미실행, stderr는 미수집 상태의 소유자·모드·행에 필요한 null 안내다. 종료2는 수집 상태와 값이 모순된 입력의 예상한 거부이며 입력 허용이 아니다.

## 실행 조건과 정리

- ZIP을 빈 폴더에 풀고 README와 세 파일이 모인 글별 폴더로 이동한다. 각 단계에서 사용하는 셸의 코드 블록 하나를 선택한다. 두 JSON은 이미 포함돼 있다.
- /home/example과 /etc/exports는 설명용 경로다. 실제 파일·폴더·공유·마운트를 만들지 않는다. 프로그램은 지정한 JSON만 읽고 임시 파일·소켓을 만들거나 원본 입력을 고치지 않는다.
- collected는 설정 파일의 ownerUid·mode·line 자료를 얻었다는 가정이다. absent·query-error·uncollected이면 세 값은 모두 null이다. 실제 수집 자료나 조회 오류를 재현한 기록은 아니다.
- ownerUid는 실습 범위의 정수, mode는 첫 자리가 0인 일반 권한 네 자리 8진수 문자열이다. 실제 파일 종류·특수 비트·ACL·소유 그룹을 수집하지 않는다.
- 공유 행은 /home/example, host1·host2·* 중 한 대상, ro 또는 rw와 root_squash를 순서대로 붙인 형식만 다룬다. 다른 경로·주석·여러 대상·옵션 순서 변경·다른 옵션은 해석 보류다.
- host1과 host2는 가상 이름이며 DNS를 조회하지 않는다. 실제 exports 문법의 전체 허용·거부나 적용 순서를 구현한 도구가 아니다. 실제 NFS·운영 설정·계정·인증·네트워크를 조회·변경하지 않는다.
- 프로그램이 만든 정리 대상은 없고 ZIP과 입력은 그대로 남는다. 오류가 나면 실행 폴더·파일명·읽기 권한, JSON·UTF-8·크기·중복, UID·모드 형식과 수집 상태의 대응을 살핀다.
