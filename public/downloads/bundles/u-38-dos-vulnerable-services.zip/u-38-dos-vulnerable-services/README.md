# U-38: DoS 공격에 취약한 서비스 비활성화

본문: https://ryuyunseong.github.io/security-blog/posts/u-38-dos-vulnerable-services/

## 준비

Python 3.12 이상과 표준 라이브러리. Windows PowerShell과 Git Bash에서 검증했다. 문자열만 해석하므로 관리자 권한·Linux 파일시스템·inetd 설치·별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
각 단계에서 사용하는 셸의 코드 블록 하나를 골라 실행한다. PowerShell은 $LASTEXITCODE, Bash는 echo $?로 Python 명령의 숫자 종료 코드를 읽는다.

```powershell
cd u-38-dos-vulnerable-services
```

## 포함 파일

- `u38_inetd_pairs.py`
- `u38_cases.json`
- `u38_rejected.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

#### PowerShell

```powershell
python -I -B -X utf8 u38_inetd_pairs.py u38_cases.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u38_inetd_pairs.py u38_cases.json
echo $?
```

예상 종료 코드: 0. 가상 사례8건: 활성 설정 후보1·활성 행 없음2·해석 보류5. 종료0은 입력 검사와 분류 완료이며 서비스 실행·통신 또는 U-38 양호 판정이 아니다.

### 2

#### PowerShell

```powershell
python -I -B -X utf8 u38_inetd_pairs.py u38_rejected.json
$LASTEXITCODE
```

#### Bash

```bash
python -I -B -X utf8 u38_inetd_pairs.py u38_rejected.json
echo $?
```

예상 종료 코드: 2. 표준 출력은 비교 미실행, 표준 오류는 미수집 text가 null이어야 한다는 입력 오류다. 종료2는 예상한 거부이며 입력 허용 결과가 아니다.

## 실행 조건과 정리

- ZIP을 빈 폴더에 풀고 README와 세 파일이 있는 글별 폴더로 이동한 뒤 사용하는 셸의 블록 하나를 선택한다. 두 JSON은 이미 포함돼 있다.
- 설정은 JSON text 안의 문자열이다. /etc/inetd.conf나 /example/echohelper 파일·폴더를 만들지 않는다. 프로그램은 지정한 JSON만 읽으며 임시 파일이나 소켓을 만들지 않는다.
- collected는 본문 자료를 얻었다는 가정이다. absent·query-error·uncollected는 실제 운영 자료가 아닌 가상 수집 상태이며 text를 null로 두고 보류한다.
- 여섯 필드와 서비스 이름·프로토콜·소켓 형식·wait/nowait·root internal만 해석한다. 대상 행의 확장 형식과 활성 쌍 중복은 보류하며 전체 inetd 파서를 대신하지 않는다.
- 운영 설정·계정·인증·서비스 조회나 변경, 패킷 전송·외부 스캔·DoS 트래픽은 없다. 프로그램이 만든 정리 대상은 없으며 ZIP과 입력은 그대로 남긴다.
- 오류 시 실행 폴더·파일명·읽기 권한, UTF-8/JSON·크기·키/ID 중복·수집 상태와 text 대응을 살핀다.
