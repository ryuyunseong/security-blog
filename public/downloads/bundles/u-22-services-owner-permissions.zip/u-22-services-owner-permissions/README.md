# U-22: /etc/services 파일 소유자 및 권한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-22-services-owner-permissions/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1에서 검증했다. 관리자 권한·별도 패키지·서버는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-22-services-owner-permissions
```

## 포함 파일

- `u22_services_table.py`
- `u22_services_sample.txt`
- `u22_services_modes.py`
- `u22_services_modes.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u22_services_table.py u22_services_sample.txt
echo $?
```

예상 종료 코드: 0. 가상 이름표 조회 또는 6건 권한 비교를 끝내면 0이다. 0은 실제 포트 상태나 모든 항목의 양호를 뜻하지 않는다. 입력 오류는 2다.

### 2

```bash
python3 -I -B -X utf8 u22_services_modes.py u22_services_modes.json
echo $?
```

예상 종료 코드: 0. 가상 이름표 조회 또는 6건 권한 비교를 끝내면 0이다. 0은 실제 포트 상태나 모든 항목의 양호를 뜻하지 않는다. 입력 오류는 2다.

## 실행 조건과 정리

- 지정한 가상 TXT·JSON만 읽는다. 운영 /etc/services·계정·파일 속성·포트는 조회하거나 바꾸지 않는다.
- 빈 폴더에 압축을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 포함된 입력은 다시 만들 필요가 없다.
- Windows PowerShell에서는 python3를 python으로 바꿀 수 있다. 명령 직후 $LASTEXITCODE, Bash에서는 echo $?로 종료 코드를 읽는다.
- 읽기·형식 오류면 파일명과 입력 필드를 살핀다. 출력 파일을 생성하지 않으므로 별도 정리는 필요하지 않다.
