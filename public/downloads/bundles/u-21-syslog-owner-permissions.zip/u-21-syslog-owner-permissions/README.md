# U-21: /etc/(r)syslog.conf 파일 소유자 및 권한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-21-syslog-owner-permissions/

## 준비

Python 3.9 이상과 표준 라이브러리. 검증은 Windows Python 3.12.1에서 수행했다. 관리자 권한·실제 로그 서비스·외부 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-21-syslog-owner-permissions
```

## 포함 파일

- `u21_syslog_records.py`
- `u21_syslog_samples.json`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u21_syslog_records.py u21_syslog_samples.json
echo $?
```

예상 종료 코드: 0. 8건 비교 완료다. 종료 0은 입력 비교 완료이며 양호 항목의 수가 아니다. 입력 오류는 2다.

## 실행 조건과 정리

- 포함된 JSON의 경로·계정명·모드는 가상 입력이다. 운영 설정 파일이나 계정·ACL·링크를 읽거나 변경하지 않는다.
- ZIP에 포함된 파일을 다시 만들 필요는 없다. 빈 폴더에 압축을 풀고 소스와 도우미를 함께 둔다.
- Windows PowerShell에서는 명령 직후 $LASTEXITCODE로 종료 코드를 읽는다.
- 출력 파일을 만들지 않는다. 별도 삭제 명령은 필요하지 않다.
