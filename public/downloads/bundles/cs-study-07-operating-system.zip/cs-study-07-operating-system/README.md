# 운영체제: 프로세스의 메모리, 페이지 주소와 교착상태

본문: https://ryuyunseong.github.io/security-blog/posts/cs-study-07-operating-system/

## 준비

Python 3.9 이상과 표준 라이브러리. Windows Python 3.12.1에서 검증했다. 관리자 권한·별도 패키지·서버는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cs-study-07-operating-system
```

## 포함 파일

- `07-os-examples.py`
- `07-os-questions.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 07-os-examples.py sharing
echo $?
```

예상 종료 코드: 0. sharing은 parent=1·child=101·shared=5, paging은 주소 변환·프레임 부재·매핑 없음, waiting은 순환 유무, 문제 파일은 네 모형 값을 대조한다. 정상 종료는 0이다.

### 2

```bash
python3 -I -B -X utf8 07-os-examples.py paging
echo $?
```

예상 종료 코드: 0. sharing은 parent=1·child=101·shared=5, paging은 주소 변환·프레임 부재·매핑 없음, waiting은 순환 유무, 문제 파일은 네 모형 값을 대조한다. 정상 종료는 0이다.

### 3

```bash
python3 -I -B -X utf8 07-os-examples.py waiting
echo $?
```

예상 종료 코드: 0. sharing은 parent=1·child=101·shared=5, paging은 주소 변환·프레임 부재·매핑 없음, waiting은 순환 유무, 문제 파일은 네 모형 값을 대조한다. 정상 종료는 0이다.

### 4

```bash
python3 -I -B -X utf8 07-os-questions.py
echo $?
```

예상 종료 코드: 0. sharing은 parent=1·child=101·shared=5, paging은 주소 변환·프레임 부재·매핑 없음, waiting은 순환 유무, 문제 파일은 네 모형 값을 대조한다. 정상 종료는 0이다.

## 실행 조건과 정리

- sharing만 실제 자식 프로세스와 두 작업 스레드를 만든다. paging·waiting·문제 파일은 메모리 모형이며 실제 커널 페이지 테이블·락·네트워크에 접근하지 않는다.
- 빈 폴더에 압축을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 포함된 입력은 다시 만들 필요가 없다.
- Windows PowerShell에서는 python3를 python으로 바꿀 수 있다. 명령 직후 $LASTEXITCODE, Bash에서는 echo $?로 종료 코드를 읽는다.
- 문제 파일은 같은 폴더의 07-os-examples.py가 필요하다. 문제를 푼 뒤 실행한다. 일반 예제의 처리된 오류는 2, 문제 파일의 미처리 예외는 1로 끝난다. 원본 파일은 변경하지 않으며 자식·풀의 종료를 기다린다.
