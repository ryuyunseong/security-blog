# U-01: root 계정 원격 접속 제한

본문: https://ryuyunseong.github.io/security-blog/posts/u-01-root-remote-login/

## 준비

Linux 또는 WSL의 Bash, awk, OpenSSH 서버 프로그램(/usr/sbin/sshd)과 ssh-keygen.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-01-root-remote-login
```

## 포함 파일

- `check_u01_ssh.sh`
- `u01_match_lab.sh`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
TMPDIR=/tmp bash u01_match_lab.sh
echo $?
```

예상 종료 코드: 0. permitrootlogin no 다음에 permitrootlogin yes가 나온다. 두 주소 조건에서 설정을 해석한 결과다.

## 실행 조건과 정리

- 가상 자료를 대상으로 실행하는 명령이다. 수집기를 인자 없이 실행하거나 실제 /etc 경로로 바꾸면 조사 범위가 달라진다.
- 명령 앞의 TMPDIR=/tmp는 이 실습 프로세스에만 적용한다. HostKey에 넣을 임시 키 경로에 공백이 섞이지 않도록 하며, ZIP을 푼 폴더에는 공백이 있어도 된다.
- 일회용 키와 설정만 생성하고 SSH 서버를 시작하지 않는다. check_u01_ssh.sh는 실제 설정을 읽는 별도 수집기이므로 이 실습 명령에서는 실행하지 않는다.
- Missing privilege separation directory 오류는 본문의 /run/sshd 준비 조건을 참고한다. 권한 분리 기능을 끄거나 실제 SSH 설정을 바꾸지 않는다.
