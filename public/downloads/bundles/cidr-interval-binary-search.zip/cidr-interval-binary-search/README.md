# CIDR 허용 목록에서 IP 찾기: 구간 병합과 이진 탐색

본문: https://ryuyunseong.github.io/security-blog/posts/cidr-interval-binary-search/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cidr-interval-binary-search
```

## 포함 파일

- `solution.py`
- `test_solution.py`
- `input.txt`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 solution.py < input.txt
echo $?
```

예상 종료 코드: 0. 본문 첫 번째 입출력 예제와 같은 결과가 나온다.

### 2

```bash
python3 -B test_solution.py
echo $?
```

예상 종료 코드: 0. 경계값과 무작위 기준 풀이 비교가 성공한다.

## 실행 조건과 정리

- solution.py·test_solution.py·input.txt를 같은 폴더에 둔다. 테스트는 같은 폴더의 solution을 가져오므로 -I를 추가하지 않는다.
- PowerShell에서는 첫 명령 대신 Get-Content .\input.txt | python .\solution.py를 사용하고, 테스트는 python -B test_solution.py로 실행할 수 있다.
