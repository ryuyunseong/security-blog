# 데이터베이스와 SQL 기초: 조회, NULL, 데이터 변경

본문: https://ryuyunseong.github.io/security-blog/posts/cs-study-01-database-sql/

## 준비

Linux 또는 WSL의 Bash, Python 3.12. 별도 Python 패키지는 사용하지 않는다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd cs-study-01-database-sql
```

## 포함 파일

- `01-database-sql.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 01-database-sql.py --record
echo $?
```

예상 종료 코드: 0. SQL 결과 22건 및 제약 조건 3건 통과와 각 쿼리 결과가 나온다.

## 실행 조건과 정리

- 가상 자료를 메모리 SQLite에 만든다. 별도 DB나 입력 파일은 필요 없다. 실행 환경과 코드 해시가 든 01-database-sql.verification.json을 코드 옆에 새로 만든다.
- 기록 파일이 이미 있으면 덮어쓰지 않고 오류로 종료한다. 새 기록이 필요 없으면 --record 없이 실행한다. Python·SQLite 버전 줄은 환경에 따라 달라진다.
