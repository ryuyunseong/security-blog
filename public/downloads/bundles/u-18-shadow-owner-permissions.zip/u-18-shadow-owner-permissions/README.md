# U-18: /etc/shadow 파일 소유자 및 권한 설정

본문: https://ryuyunseong.github.io/security-blog/posts/u-18-shadow-owner-permissions/

## 준비

Python 3.12와 표준 라이브러리. Linux·WSL에서는 python3, Windows에서는 python을 사용한다. 관리자 권한과 별도 패키지는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-18-shadow-owner-permissions
```

## 포함 파일

- `u18_shadow_mode.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u18_shadow_mode.py
echo $?
```

예상 종료 코드: 0. 기대값 비교를 마치고 종료 코드 0, 빈 표준 오류로 끝난다. 출력 필드와 비교 범위는 본문의 코드 설명과 대조한다.

## 실행 조건과 정리

- 가상 자료는 코드 안에 있다. 입력 파일·계정·DB 서버를 준비하지 않는다.
- Windows에서는 명령의 python3를 python으로 바꾸고 명령 직후 $LASTEXITCODE를 조회한다.
- 새 파일을 만들지 않으며 메모리 자원은 종료 시 정리된다. 별도 삭제 명령은 필요하지 않다.
