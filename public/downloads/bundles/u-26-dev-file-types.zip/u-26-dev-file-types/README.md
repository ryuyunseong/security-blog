# U-26: /dev에 존재하지 않는 device 파일 점검

본문: https://ryuyunseong.github.io/security-blog/posts/u-26-dev-file-types/

## 준비

Linux 또는 WSL Ubuntu, Python 3.9 이상과 GNU find. /tmp에 FIFO·심볼릭 링크를 만들 수 있어야 한다. Ubuntu 24.04의 Python 3.12.3에서 검증했다. 관리자 권한·별도 패키지·네트워크는 필요하지 않다.

ZIP을 빈 폴더에 풀고, 아래 파일이 모여 있는 폴더로 이동한다.
Windows에서는 파일 탐색기의 모두 추출을 사용할 수 있다.
아래 실행 명령은 Linux/WSL의 Bash 기준이다. Python 예제의 assert 검사를 끄는 -O 옵션은 사용하지 않는다.

```bash
cd u-26-dev-file-types
```

## 포함 파일

- `u26_file_types.py`
- `u26_fixture_lab.py`
- `README.md`: 준비 조건, 실행 명령과 결과 읽는 방법

## 실행

### 1

```bash
python3 -I -B -X utf8 u26_fixture_lab.py ./u26_file_types.py
echo $?
```

예상 종료 코드: 0. 항목 8건 중 일반 파일 4건과 예외 영역 2건을 출력한다. GNU find 일반 파일 4건과 일치하고 자신의 임시 폴더를 정리한다. 정상 종료 0, 준비·수집·비교 오류는 2다.

## 실행 조건과 정리

- 빈 폴더에 ZIP을 풀고 이 README가 있는 글별 폴더에서 명령을 실행한다. 두 Python 파일을 같은 폴더에 둔다. 입력을 따로 준비하지 않는다.
- Linux/WSL에서 python3 명령을 사용하고 직후 echo $?로 종료 코드를 읽는다. Windows Python에서는 실행하지 않는다.
- 준비기가 /tmp에 자신만 접근할 수 있는 가상 폴더·표지·자료를 만들고 정상·실패 때 그 폴더만 정리한다. 운영 /dev 경로를 전달하지 않는다.
- shm·mqueue는 가상 디렉터리 이름이며 실제 공유 메모리·메시지 큐 마운트가 아니다. FIFO를 열거나 문자·블록 장치를 만들지 않는다. 메모리 모드 예시는 파일시스템 항목 8건과 별개다.
